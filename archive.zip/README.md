# TAREA_3_OCR

### Esta práctica consistió en usar la interfaz gráfica para ejecutar comandos de git

# Cómo ejecutar el proyecto

### descarga los archivos y ejecuta la extensión live server
