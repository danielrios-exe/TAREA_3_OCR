let num_a = 5,
num_b = 10;
let res = num_a - num_b;
console.log('Resultado', res);
alert('Práctica 1');

